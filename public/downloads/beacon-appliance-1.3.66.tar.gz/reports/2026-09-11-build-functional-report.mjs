import fs from 'node:fs';

const outputPath = new URL('./2026-09-11-moticlaw-vs-beacon-functional-gap-report.html', import.meta.url);
let html = fs.readFileSync(outputPath, 'utf8');

const esc = (value) => String(value ?? '')
  .replaceAll('&', '&amp;')
  .replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;');

const evidenceLabel = {
  direct: ['直接实测', 'ev-direct'],
  bundle: ['包内发现', 'ev-bundle'],
  repo: ['仓库核对', 'ev-repo'],
  inference: ['分析判断', 'ev-inference'],
};

function evidence(type, note = '') {
  const [label, cls] = evidenceLabel[type] ?? evidenceLabel.inference;
  return `<span class="evidence-tag ${cls}"${note ? ` title="${esc(note)}"` : ''}>${label}</span>`;
}

function status(value) {
  const cls = value.includes('更强') || value.includes('完整') ? 'st-good'
    : value.includes('部分') || value.includes('条件') ? 'st-partial'
      : value.includes('不适用') || value.includes('不必') ? 'st-neutral'
        : 'st-gap';
  return `<span class="status ${cls}">${esc(value)}</span>`;
}

const capabilities = [
  ['员工基础', '运行框架安装与模型配置', 'Hermes / OpenClaw 安装、模型、系统服务状态', 'direct', '烽火台自有执行内核与 BYOK 路由', '架构不同，不是产品缺口', '不照搬多框架安装器；只借健康诊断'],
  ['员工基础', 'AI 员工创建与生命周期', '创建/认领、工作/空闲/离线/异常/离职、暂停/恢复/解散、导入导出', 'direct', 'WorkflowTemplate 可安装/卸载，自主模式可运行', '部分：缺统一员工对象与生命周期视图', 'P0 建数字员工档案，底层仍以模板+运行推导'],
  ['员工基础', '按员工配置能力边界', '模型、框架、技能、知识、渠道、浏览器、搜索、图像等', 'bundle', 'toolAllowlist、callBudget、authMode、WorkflowTemplate.config', '底层较强，配置入口分散', 'P0 档案汇总，P1 能力注册表'],
  ['员工基础', '员工在线/健康状态', '管理/巡查模式，工作/空闲/离线/异常筛选', 'direct', 'AgentRun 有运行/等待/失败状态，渠道与浏览器各有状态', '部分：没有员工级计算口径', '定义状态机：可用、忙碌、受阻、故障、停用'],
  ['员工基础', '安全与授权', '伙伴保护、沙箱和能力限制入口', 'bundle', '逐步确认/预授权/无人值守、contract 硬确认、工具白名单、调用预算', '烽火台底层更强', '保留现有硬闸，员工档案只做可解释汇总'],
  ['知识与工具', '员工专属知识库', '本地文件/文件夹建库、分配伙伴、生成使用说明、受控自进化', 'bundle', '人设、素材、资料库、ContentSkill 已有，主要按工作区/账号使用', '部分：缺员工绑定、引用和效果归因', 'P1 新增最小绑定关系与引用审计'],
  ['知识与工具', '技能库与员工分配', '技能库、使用统计、分配到伙伴', 'bundle', 'ContentSkill 可安装/卸载、URL 导入、AI 蒸馏、导入导出；ProcedureSkill 可从运行提炼', '能力强，但员工级分配/使用数据不完整', 'P1 统一技能、流程技能和员工可用范围'],
  ['知识与工具', '工具市场与依赖检查', '已安装/市场，CLI 与第三方工具卡片', 'direct', '静态工具、AgentToolDef、浏览器插件、机器人连接等已存在', '部分：没有统一安装状态与依赖探针', 'P1 做能力注册表，不复制通用 CLI 商店'],
  ['知识与工具', 'AI 自写工具', '通用工具生态，是否支持受控自写需运行验证', 'bundle', 'AgentToolDef 支持模型起草、人工审代码后启用、node:vm 限制', '烽火台更强且更可治理', '作为差异化保留，不需追随竞品'],
  ['任务与排班', '一键重复任务', '任务/计划相关能力在包内存在', 'bundle', 'TaskPreset 保存目标、员工和授权范围，可被定时引用', '烽火台完整', '把入口纳入员工档案与运营中心'],
  ['任务与排班', '定时任务时间轴', '周期过滤、时间窗、员工过滤、重叠筛选、时间槽', 'direct', 'ScheduledAgent 支持周几/时分、北京时间、每日上限、连败自停', '部分：只有配置列表，没有未来实例运营', 'P0 投影未来 7/30 天实例、冲突、预算与补跑'],
  ['任务与排班', '群组与渠道派工', '创建群组并自动关联飞书群、加入已连接飞书的伙伴', 'direct', 'BotIntegration 与群机器人派工、进度回执已存在', '部分：缺群组—员工花名册与责任范围', 'P1 先补群/账号/员工绑定，不复制独立群组产品'],
  ['任务与排班', '多员工团队编排', '角色、负责人派工、流程接力、产出把关、专项小组、演练', 'bundle', 'parentRunId、child-run、角色提示与权限收窄已存在', '部分：缺可复用交接协议和演练', 'P2 先做固定内容接力模板，不上任意画布'],
  ['任务与排班', '任务看板与验收返工', '看板、指派、优先级、产物、验收/驳回/返工、动态', 'bundle', 'AgentRun、AgentArtifact、AgentStep 可记录执行，但无跨阶段业务工单', '部分：执行记录不等于内容工单', 'P1 做内容工单，串选题→草稿→审校→发布→复盘'],
  ['任务与排班', '可挂起与恢复执行', '需要实际运行验证', 'bundle', 'queued/running/awaiting_confirm/waiting_browser/waiting_quota/done/failed/cancelled，租约与唤醒完备', '烽火台更强', '在运营中心把受阻原因与恢复动作显性化'],
  ['成本与结果', 'Token/费用总览', '总览、工具、伙伴三个维度；7/14/30天、趋势、热力、排行', 'direct', 'LlmCallLog 有 prompt/completion token、costUsd、source、mock/degraded、runId', '部分：账本强，运营查询弱', 'P0 每次运行、员工、任务和产物的成本归因'],
  ['成本与结果', '工具调用分析', '工具调用次数与工具 Token 视图', 'direct', 'AgentStep 可数工具调用，LlmCallLog 可算运行成本，但无法严谨拆到每个工具内部模型调用', '部分：先做调用量与运行成本，避免伪精确', 'P0 明确粒度；必要时以后加 toolCallId'],
  ['成本与结果', '员工绩效评估', '绩效页与多维评分框架', 'direct', '没有员工绩效汇总，但有运行、成本、产物与发布数据', '缺功能，但不应照搬总分', 'P2 做可靠性、时效、采用率、返工率、单位交付成本'],
  ['成本与结果', '步骤审计与产物追踪', '任务系统可展示结果/文件，细节待运行验证', 'bundle', 'AgentStep 记录工具/参数/结果/拒绝，AgentArtifact 关联业务产物', '烽火台更强', 'P0 将审计链纳入每次运行的结果页'],
  ['内容生产', '笔记创作与 AI 修改', 'Human Space 提供笔记创作', 'direct', 'Draft/DraftVersion、编辑器、AI 润色、标题封面、配图等更完整', '烽火台更强', '不借笔记壳，继续强化专业内容链路'],
  ['内容生产', '画布录制', '多画幅，应用声明摄像头/麦克风用于头像与旁白叠加', 'direct', '当前没有脚本→提词→录制的原生闭环', '明确缺口', 'P2 桌面端做 9:16/16:9 最小实验'],
  ['内容生产', '热点到发布再到效果', '通用 Agent 能力，未发现同等内容增长闭环', 'inference', '热点、同行、资料、选题、草稿、配图、合规、发布、数据复盘齐全', '烽火台核心优势', '所有借鉴必须回到内容交付与增长结果'],
  ['系统运营', '模型/渠道/服务设置', '模型、Hermes/OpenClaw 服务、飞书/Telegram/微信状态', 'direct', 'BYOK 路由、机器人渠道、插件执行器、运行设置已有', '部分：诊断入口分散', 'P1 员工健康页聚合探针和最近故障'],
  ['系统运营', '备份与恢复', '本地 ZIP、一键备份、历史记录', 'direct', '有账号数据导出/保留机制，桌面端非本地 Agent 容器', '架构不同，优先级低', '只做配置/诊断包导出，不照搬整机备份'],
  ['系统运营', '清理、SSH、远程与移动设备', '系统清理、SSH、其他设备、手机连接', 'direct', '不是内容增长主线', '不适用', '明确不借，防止产品变成通用系统管家'],
  ['功能可信度', '真实空状态与演示隔离', '空状态明确显示 0 员工/0 群组/未配置', 'direct', 'Runs 无真实数据时使用 DEMO_ROWS；工作流双栏含硬编码默认项', '严重缺口', 'P0 删除回退或显式 Demo 工作区隔离'],
];

const borrowSpecs = [
  {
    p: 'P0', name: '功能真相层：演示与真实数据彻底隔离', value: '没有可信状态，后续所有员工、成本和绩效功能都不成立。',
    base: 'RunsClientView 的 rows、数据库中的已安装模板与真实定时记录。',
    build: '生产工作区 rows=[] 就展示真实空状态；DEFAULT_ROUTINES/DEFAULT_AGENTS 只能进入显式“体验示例”数据集，并带 demo=true。',
    data: '不新增业务表；统一 EmptyStateReason 与 isDemo 标记。', api: '所有列表 API 返回 source=real|demo，生产默认只取 real。',
    accept: '新工作区中不存在虚构员工、日程或成功运行；自动化测试断言空数据不渲染示例。', risk: '短期页面会显得更空，但这是修复产品可信度。'
  },
  {
    p: 'P0', name: '数字员工档案 AgentOverview', value: '一处回答“这个员工会什么、现在能不能干、正在干什么、最近交付如何”。',
    base: 'WorkflowTemplate + AgentRun + ScheduledAgent + LlmCallLog + ProcedureSkill + AgentToolDef + BotIntegration + AgentArtifact。',
    build: '员工状态、当前运行、近7/30天成功率、等待原因、调用预算、授权档、技能/工具/渠道、定时、成本、产物与最近错误；支持暂停/恢复/派任务/看运行。',
    data: '先做只读 AgentOverview 聚合，不新建 Agent 表；状态由模板启用状态与最近运行推导。', api: 'GET /api/agents/:templateId/overview；GET /api/agents?status=&channel=&capability=。',
    accept: '用户从任一运行 1 次点击到员工档案；状态与原始运行一致；所有指标可下钻；空数据不补默认值。', risk: '状态计算口径必须文档化，不能由前端各算一套。'
  },
  {
    p: 'P0', name: '定时任务运营中心 ScheduleOps', value: '从“配了一个定时”升级为“能预测、发现冲突、处理失败和控制成本”。',
    base: 'ScheduledAgent 的 target、周几/时分、enabled、failStreak、lastRunAt/lastError；已有北京时间、每日上限与失败自停。',
    build: '未来7/30天实例时间轴、周期/员工/账号/状态过滤、重叠、错过、补跑、跳过一次、暂停、预计调用预算与最近结果。',
    data: 'ScheduleOccurrence 为计算型 read model；首版不落库。需要例外时再增加 ScheduleException。', api: 'GET /api/schedules/occurrences?from=&to=&agentId=；POST /api/schedules/:id/run-now|skip|pause。',
    accept: '未来7天每个实例可解释来源；同员工/同账号冲突被标出；连续失败原因可见；补跑产生可追踪 AgentRun。', risk: '预计成本只给区间，避免把调用预算误当真实费用。'
  },
  {
    p: 'P0', name: '运行成本与产物结果 RunEconomics', value: '把“跑完了”改成“花了多少、做了什么、能不能用”。',
    base: 'LlmCallLog.runId、token、costUsd、source、mocked/degraded；AgentStep；AgentArtifact。',
    build: '每次运行展示总调用、Token、真实成本、平台/BYOK、预算使用率、工具次数、等待时长、产物清单与最终状态；按员工和任务汇总。',
    data: 'RunEconomics 为查询聚合；以后若需工具级模型成本，再在账本增加 toolCallId，首版不伪拆分。', api: 'GET /api/runs/:id/economics；GET /api/agents/:id/economics?range=30d。',
    accept: '账单合计与 LlmCallLog 一致；mock/degraded 显式展示；每个产物能打开；预算超限与真实成本不混淆。', risk: '不同模型价格口径与历史 unknown source 要如实标注。'
  },
  {
    p: 'P1', name: '员工知识绑定与引用 AgentKnowledge', value: '让不同员工真正“读不同资料、按不同规则做事”，并能解释答案来自哪里。',
    base: 'Material、资料库、人设、ContentSkill 与账号上下文。',
    build: '选择员工可读知识源、用途说明、优先级、启停、最近索引时间、引用命中；产物可回溯引用。',
    data: '新增 AgentKnowledgeBinding(templateId, sourceType, sourceId, purpose, priority, enabled)；引用写入运行步骤或独立 RunCitation。', api: 'PUT /api/agents/:id/knowledge；GET /api/runs/:id/citations。',
    accept: '同一任务换员工后可验证知识范围不同；所有外部事实引用可定位源对象；禁用后下一次运行不再检索。', risk: '自动进化首版不做；原始资料只读，所有修改需版本化。'
  },
  {
    p: 'P1', name: '内容工单 ContentWorkItem', value: '复制 MotiClaw 的“任务验收”思想，但以烽火台的内容生命周期为骨架。',
    base: 'Topic、Draft/DraftVersion、PublishRecord、AgentRun、AgentArtifact 及合规结果。',
    build: '阶段：候选选题→起稿→审校→待发布→已发布→复盘；负责人/员工、截止、输入、验收标准、交付物、驳回原因、返工次数。',
    data: '新增 ContentWorkItem 与 WorkItemEvent；业务对象继续保持各自真相，工单只做关联和流程状态。', api: 'POST/PUT /api/work-items；POST /api/work-items/:id/accept|reject|rework。',
    accept: '一张工单可回溯主题、所有草稿版本、运行、发布与复盘；驳回必须有原因；返工不会覆盖旧交付。', risk: '不能再复制草稿正文或发布状态，避免双写。'
  },
  {
    p: 'P1', name: '能力注册表 CapabilityRegistry', value: '用户看到的不是三个相似市场，而是“这个员工当前能否调用这项能力”。',
    base: 'ContentSkill、SkillInstall、ProcedureSkill、AgentToolDef、静态工具、BrowserTask、BotIntegration。',
    build: '统一显示能力类型、已安装、已授权、依赖满足、最近调用、成功率、成本属性、写/合同风险、可分配员工；提供探针测试。',
    data: '首版 read model；只为员工分配关系新增绑定，不迁移原始技能/工具表。', api: 'GET /api/capabilities；POST /api/capabilities/:id/probe；PUT /api/agents/:id/capabilities。',
    accept: '“安装成功但不可用”可被识别；缺密钥/插件/渠道有明确修复动作；风险等级来自服务端工具定义。', risk: '概念命名要收敛，避免技能/工具/能力/连接器继续互相重叠。'
  },
  {
    p: 'P1', name: '员工健康与异常收件箱', value: '借 MotiClaw 健康/修复思想，但只覆盖影响内容任务的依赖。',
    base: '模型路由与 Key、浏览器任务、机器人渠道、AgentRun.error、定时 lastError/failStreak、AgentToolDef.lastError。',
    build: '模型、渠道、浏览器执行器、知识索引、工具探针、定时器六类健康；异常按影响员工/任务聚合；重试、改配置、停用与导出诊断包。',
    data: 'HealthCheckResult 可短期缓存，不作为业务真相；每项仍回链原系统。', api: 'GET /api/health/agents；POST /api/health/check?scope=；POST /api/support-bundle。',
    accept: '每个红色状态有证据时间、影响范围和动作；修复前确认；不提供磁盘清理或通用 SSH。', risk: '自动修复容易扩大故障，首版默认只读诊断。'
  },
  {
    p: 'P2', name: '固定角色接力 HandoffTemplate', value: '让研究、写作、审校、发布形成可复用协作，而不是炫技式多 Agent。',
    base: 'parentRunId、child-run、角色提示、toolAllowlist、AgentArtifact、权限只能收窄。',
    build: '首批三条模板：情报→选题；选题→写稿→审校；发布→数据→复盘。每一跳定义输入、结构化交付、验收人、失败回退、最大预算。',
    data: '先存 WorkflowTemplate.config，不急建图结构；成熟后再拆 HandoffTemplate/Step。', api: 'POST /api/handoffs/:template/run；POST /api/handoffs/:run/approve|rework。',
    accept: '子运行最多一层；权限不扩大；上一跳无合格产物则下一跳不启动；总预算和每跳成本可见。', risk: '不要首版支持任意连线、循环和动态扩员。'
  },
  {
    p: 'P2', name: '内容视频化：脚本到画布录制', value: 'MotiClaw 的画布录制与烽火台脚本、标题、素材结合后，可能形成独特内容闭环。',
    base: 'Studio 草稿、封面/配图、桌面客户端与多平台内容能力。',
    build: '草稿生成提词稿与分镜；选择 9:16/16:9；录屏/摄像头/麦克风；自动分页、提词、素材叠加；产出视频文件并回到内容工单。',
    data: '首版媒体文件本地保存，只上传元数据与显式选择的成品；验证后再设计 MediaProject。', api: '桌面 IPC：record.start/pause/finish；Web 端只接收 artifact 回执。',
    accept: '10分钟内从现有草稿录出一条可预览短视频；权限提示清晰；失败不丢本地文件；用户主动确认上传。', risk: '音视频工程复杂，必须独立实验，不能阻塞 P0/P1。'
  },
  {
    p: 'P2', name: '可解释员工绩效，不做万能总分', value: '用内容交付硬指标帮助淘汰无效自动化，而不是制造管理幻觉。',
    base: 'AgentRun、LlmCallLog、AgentArtifact、ContentWorkItem、PublishRecord。',
    build: '五项：运行可靠性、交付时效、被接受产物率、返工率、每个接受产物成本；另列样本量与异常原因。',
    data: '全是派生指标，不存最终总分；指标定义版本化。', api: 'GET /api/agents/:id/performance?range=30d&metricVersion=v1。',
    accept: '每个指标可下钻到样本；样本不足显示“不足”，不补分；不将曝光量直接归功于某次 Agent。', risk: '发布效果受账号、选题与时机影响，不能做过度因果归因。'
  },
];

const roadmap = [
  ['第 0–2 周', '可信与可见', '移除假数据；AgentOverview 只读聚合；RunEconomics 单次运行页', '3 个智能体 × 10 次真实任务；摘要与原始数据一致率 100%'],
  ['第 3–5 周', '排班与异常', '未来实例时间轴、冲突、预计预算、失败收件箱、补跑/暂停', '异常发现时间下降 50%；失败定时不再持续静默烧额度'],
  ['第 6–8 周', '知识与内容工单', '员工知识绑定、引用；ContentWorkItem 验收/返工；能力注册表', '被接受产物率提升；返工原因可统计；安装但不可用问题可诊断'],
  ['第 9–12 周', '协作与新媒介实验', '3 条固定角色接力；可解释绩效；桌面录制小流量实验', '接力任务成功率、单位交付成本达标后再扩；录制实验不过门槛即停止'],
];

const priorityCounts = borrowSpecs.reduce((acc, item) => {
  acc[item.p] = (acc[item.p] ?? 0) + 1;
  return acc;
}, {});

const capabilityRows = capabilities.map((row) => `<tr>
  <td><span class="domain-label">${esc(row[0])}</span></td>
  <td><strong>${esc(row[1])}</strong></td>
  <td>${esc(row[2])}<div class="cell-evidence">${evidence(row[3])}</div></td>
  <td>${esc(row[4])}<div class="cell-evidence">${evidence('repo')}</div></td>
  <td>${status(row[5])}</td>
  <td>${esc(row[6])}</td>
</tr>`).join('');

const borrowCards = borrowSpecs.map((item, index) => `<article class="spec-card" id="spec-${index + 1}">
  <header><span class="priority ${item.p.toLowerCase()}">${item.p}</span><h3>${index + 1}. ${esc(item.name)}</h3></header>
  <p class="spec-value">${esc(item.value)}</p>
  <dl>
    <div><dt>烽火台已有底座</dt><dd>${esc(item.base)}</dd></div>
    <div><dt>新增功能</dt><dd>${esc(item.build)}</dd></div>
    <div><dt>数据设计</dt><dd>${esc(item.data)}</dd></div>
    <div><dt>接口建议</dt><dd><code>${esc(item.api)}</code></dd></div>
    <div class="accept"><dt>验收标准</dt><dd>${esc(item.accept)}</dd></div>
    <div class="riskline"><dt>主要风险</dt><dd>${esc(item.risk)}</dd></div>
  </dl>
</article>`).join('');

const roadmapRows = roadmap.map((row) => `<tr>${row.map((cell, i) => `<td${i === 0 ? ' class="phase"' : ''}>${esc(cell)}</td>`).join('')}</tr>`).join('');

const functionSections = `
<nav class="function-toc" aria-label="功能报告目录">
  <a href="#functional-verdict">功能结论</a>
  <a href="#capability-matrix">完整矩阵</a>
  <a href="#borrow-specs">落地规格</a>
  <a href="#architecture">功能架构</a>
  <a href="#roadmap">90 天路线</a>
  <a href="#do-not-copy">明确不借</a>
</nav>

<section class="report-section function-callout" id="functional-verdict">
  <div class="section-head">
    <p class="eyebrow">纠偏说明</p>
    <h2>这份报告只讨论功能，不做界面仿制</h2>
    <p>“借鉴”被定义为：新增真实状态、动作、数据关系、权限边界和可验收结果。颜色、布局、双空间导航都不作为核心结论。</p>
  </div>
  <div class="verdict-grid">
    <article><span>真正要借</span><strong>数字员工运营闭环</strong><p>员工档案、排班、成本、知识、健康、验收与接力。</p></article>
    <article><span>烽火台已有</span><strong>执行与安全内核</strong><p>运行状态机、授权、预算、步骤审计、产物、定时和子运行。</p></article>
    <article><span>绝对不要</span><strong>复制通用 Agent OS</strong><p>不优先做 SSH、文件清理、多框架安装器和通用 CLI 商店。</p></article>
  </div>
  <div class="north-star">
    <b>北极星任务：</b>让运营负责人能在 10 分钟内回答：谁在做什么、下一次何时跑、为什么卡住、花了多少、交付能不能用、要不要返工。
  </div>
</section>

<section class="report-section evidence-scope">
  <div class="section-head">
    <h2>证据口径</h2>
    <p>避免把“代码里有入口”写成“本机已可用”。本报告对 MotiClaw 功能分四级标注。</p>
  </div>
  <div class="legend-grid">
    <div>${evidence('direct')}<p>本机 MotiClaw 0.3.7 中直接打开并看到功能页、状态或配置项。</p></div>
    <div>${evidence('bundle')}<p>安装包前端模块/路由中存在，但受 Hermes/OpenClaw 未安装影响，未完成端到端运行验证。</p></div>
    <div>${evidence('repo')}<p>烽火台仓库的 schema、服务逻辑或页面代码中核对到。</p></div>
    <div>${evidence('inference')}<p>基于产品边界做出的建议，不冒充已实现事实。</p></div>
  </div>
  <p class="scope-note"><strong>当前限制：</strong>MotiClaw 已登录，但新手流程仍显示 Hermes/OpenClaw 未安装、0 个 AI 伙伴，因此“团队、任务看板、知识自进化”等包内能力只能作为产品设计证据，不能评价其稳定性、成功率或真实体验。</p>
</section>

<section class="report-section" id="capability-matrix">
  <div class="section-head">
    <p class="eyebrow">26 项功能逐项核对</p>
    <h2>功能能力矩阵</h2>
    <p>先看事实，再做优先级。横向滚动表保留完整描述，打印时会自动压缩。</p>
  </div>
  <div class="matrix-wrap">
    <table class="functional-matrix">
      <thead><tr><th>领域</th><th>功能</th><th>MotiClaw</th><th>烽火台现状</th><th>差距判断</th><th>处理决定</th></tr></thead>
      <tbody>${capabilityRows}</tbody>
    </table>
  </div>
  <div class="matrix-summary">
    <div><b>烽火台更强</b><span>执行状态、权限硬闸、步骤审计、AI 自写工具、内容增长闭环</span></div>
    <div><b>MotiClaw 更完整</b><span>员工生命周期、排班运营、成本聚合、知识分配、健康维护、任务验收</span></div>
    <div><b>最值得结合</b><span>MotiClaw 的员工运营方式 × 烽火台的内容业务对象和安全内核</span></div>
  </div>
</section>

<section class="report-section" id="borrow-specs">
  <div class="section-head">
    <p class="eyebrow">${priorityCounts.P0} 个 P0 · ${priorityCounts.P1} 个 P1 · ${priorityCounts.P2} 个 P2</p>
    <h2>烽火台可直接立项的功能规格</h2>
    <p>每项都写清复用底座、新功能、数据/接口、验收标准和风险。这里才是本报告的主体。</p>
  </div>
  <div class="spec-grid">${borrowCards}</div>
</section>

<section class="report-section" id="architecture">
  <div class="section-head">
    <h2>建议的功能架构：一个闭环，两个新增真对象</h2>
    <p>大部分新功能应是现有数据的聚合，不要重复建表。真正需要新增持久化模型的，首阶段只有知识绑定和内容工单。</p>
  </div>
  <div class="architecture-flow">
    <div class="flow-node existing"><small>现有输入</small><b>热点 / 同行 / 资料</b><span>Topic · Material · Library</span></div>
    <div class="flow-arrow">→</div>
    <div class="flow-node new"><small>新增真对象 ①</small><b>内容工单</b><span>ContentWorkItem · 验收 · 返工</span></div>
    <div class="flow-arrow">→</div>
    <div class="flow-node existing"><small>现有执行</small><b>数字员工运行</b><span>AgentRun · Step · Artifact</span></div>
    <div class="flow-arrow">→</div>
    <div class="flow-node existing"><small>现有业务</small><b>草稿 / 发布 / 复盘</b><span>Draft · PublishRecord · Data</span></div>
  </div>
  <div class="architecture-underlay">
    <article><span>新增真对象 ②</span><b>AgentKnowledgeBinding</b><p>规定每个员工可读什么，并保留引用。</p></article>
    <article><span>只读聚合</span><b>AgentOverview</b><p>从模板、运行、定时、成本、能力和渠道推导。</p></article>
    <article><span>只读聚合</span><b>ScheduleOccurrence</b><p>按规则计算未来实例，不先落库制造第二真相。</p></article>
    <article><span>只读聚合</span><b>RunEconomics</b><p>从账本、步骤和产物计算成本与结果。</p></article>
  </div>
  <div class="rule-box"><b>硬规则：</b>状态、成本、权限、发布结果继续以现有原始表为权威；新增聚合层必须能一键下钻到原始运行。ContentWorkItem 只关联业务对象，不复制正文、发布状态或成本。</div>
</section>

<section class="report-section" id="roadmap">
  <div class="section-head">
    <h2>90 天功能路线</h2>
    <p>顺序按依赖而不是吸引力：先修真相，再做管理；先单员工闭环，再做团队接力。</p>
  </div>
  <div class="matrix-wrap">
    <table class="roadmap-table"><thead><tr><th>阶段</th><th>目标</th><th>交付功能</th><th>过门槛证据</th></tr></thead><tbody>${roadmapRows}</tbody></table>
  </div>
  <div class="metric-strip">
    <div><span>可靠性</span><b>成功完成 / 有效发起</b></div>
    <div><span>时效</span><b>从发起到可验收产物</b></div>
    <div><span>采用</span><b>被接受产物 / 全部产物</b></div>
    <div><span>返工</span><b>每个接受产物的返工次数</b></div>
    <div><span>单位成本</span><b>真实 AI 成本 / 接受产物</b></div>
  </div>
</section>

<section class="report-section do-not-copy" id="do-not-copy">
  <div class="section-head">
    <h2>明确不借，至少现在不借</h2>
    <p>这是保持烽火台产品边界最重要的一部分。</p>
  </div>
  <div class="no-grid">
    <article><b>多框架安装器</b><p>烽火台已有执行内核；支持 Hermes/OpenClaw 只会新增维护面。</p></article>
    <article><b>通用 CLI 市场</b><p>只保留对内容业务有明确价值且能做依赖探针的能力。</p></article>
    <article><b>SSH / 远程设备</b><p>与内容增长主线弱相关，安全和支持成本高。</p></article>
    <article><b>文件清理管家</b><p>桌面壳无需变成系统工具箱；只做诊断包和必要缓存管理。</p></article>
    <article><b>任意多 Agent 画布</b><p>没有交接契约和验收前，画布只是复杂性放大器。</p></article>
    <article><b>八维绩效总分</b><p>优先使用可下钻的五项硬指标，样本不足就明确不足。</p></article>
    <article><b>双空间信息架构</b><p>Agent Space / Human Space 是 MotiClaw 的组织方式，不是功能能力。</p></article>
    <article><b>整机式备份</b><p>烽火台更需要账号配置、诊断与数据导出，不需要复制本地 Agent 容器。</p></article>
  </div>
</section>`;

const customCss = `
    .function-toc { display:flex; flex-wrap:wrap; gap:8px; padding:12px 14px; border:1px solid var(--line); border-radius:12px; background:var(--surface); position:sticky; top:8px; z-index:5; box-shadow:0 8px 24px rgb(22 32 46 / .08); }
    .function-toc a { padding:6px 10px; border-radius:8px; background:var(--surface-soft); color:var(--ink-soft); font-size:12px; font-weight:700; }
    .function-callout { border-color:color-mix(in srgb, var(--accent) 36%, var(--line)); }
    .eyebrow { color:var(--accent) !important; font-size:12px !important; font-weight:800; text-transform:uppercase; letter-spacing:.08em; }
    .verdict-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:12px; }
    .verdict-grid article { border:1px solid var(--line-soft); border-radius:12px; background:var(--surface-soft); padding:15px; }
    .verdict-grid span,.architecture-underlay span { display:block; color:var(--muted); font-size:11px; font-weight:800; margin-bottom:5px; }
    .verdict-grid strong { display:block; font-size:18px; line-height:1.25; color:var(--accent-ink); }
    .verdict-grid p { margin-top:8px; color:var(--ink-soft); font-size:13px; }
    .north-star,.rule-box,.scope-note { margin-top:14px; border-left:4px solid var(--accent); padding:12px 14px; background:var(--accent-soft); border-radius:0 10px 10px 0; color:var(--ink-soft); }
    .legend-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px; }
    .legend-grid>div { border:1px solid var(--line-soft); border-radius:10px; padding:12px; background:var(--surface-soft); }
    .legend-grid p { margin-top:8px; font-size:13px; color:var(--ink-soft); }
    .evidence-tag { display:inline-flex; align-items:center; border-radius:999px; padding:3px 8px; font-size:10px; font-weight:800; white-space:nowrap; }
    .ev-direct { background:var(--ok-soft); color:var(--ok); }
    .ev-bundle { background:var(--warn-soft); color:var(--warn); }
    .ev-repo { background:var(--accent-soft); color:var(--accent-ink); }
    .ev-inference { background:var(--surface-strong); color:var(--muted); }
    .matrix-wrap { width:100%; overflow:auto; border:1px solid var(--line); border-radius:11px; }
    .functional-matrix,.roadmap-table { width:100%; border-collapse:collapse; min-width:1080px; font-size:12px; }
    .functional-matrix th,.functional-matrix td,.roadmap-table th,.roadmap-table td { text-align:left; vertical-align:top; border-bottom:1px solid var(--line-soft); padding:11px 12px; }
    .functional-matrix th,.roadmap-table th { position:sticky; top:0; background:var(--surface-strong); color:var(--ink-soft); font-size:11px; z-index:1; }
    .functional-matrix tr:last-child td,.roadmap-table tr:last-child td { border-bottom:0; }
    .functional-matrix tbody tr:hover { background:var(--surface-soft); }
    .functional-matrix th:nth-child(1){width:8%}.functional-matrix th:nth-child(2){width:13%}.functional-matrix th:nth-child(3){width:21%}.functional-matrix th:nth-child(4){width:21%}.functional-matrix th:nth-child(5){width:13%}.functional-matrix th:nth-child(6){width:24%}
    .domain-label { color:var(--muted); font-weight:800; }
    .cell-evidence { margin-top:7px; }
    .status { display:inline-block; padding:4px 8px; border-radius:7px; font-size:10px; font-weight:800; }
    .st-good { background:var(--ok-soft); color:var(--ok); }.st-partial { background:var(--warn-soft); color:var(--warn); }.st-gap { background:var(--risk-soft); color:var(--risk); }.st-neutral { background:var(--surface-strong); color:var(--muted); }
    .matrix-summary { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:10px; margin-top:12px; }
    .matrix-summary>div { padding:12px; border:1px solid var(--line-soft); border-radius:10px; }
    .matrix-summary b,.matrix-summary span { display:block; }.matrix-summary span { margin-top:5px; color:var(--ink-soft); font-size:12px; }
    .spec-grid { display:grid; gap:12px; }
    .spec-card { border:1px solid var(--line); border-radius:12px; overflow:hidden; background:var(--surface-soft); }
    .spec-card header { display:flex; align-items:center; gap:9px; padding:13px 15px; border-bottom:1px solid var(--line-soft); background:var(--surface); }
    .spec-card header h3 { font-size:16px; }.priority { display:inline-flex; padding:3px 7px; border-radius:6px; font-size:10px; font-weight:900; }
    .priority.p0 { background:var(--risk-soft); color:var(--risk); }.priority.p1 { background:var(--warn-soft); color:var(--warn); }.priority.p2 { background:var(--accent-soft); color:var(--accent-ink); }
    .spec-value { padding:12px 15px; color:var(--accent-ink); font-weight:700; border-bottom:1px solid var(--line-soft); }
    .spec-card dl { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); margin:0; }
    .spec-card dl>div { padding:12px 15px; border-bottom:1px solid var(--line-soft); }
    .spec-card dl>div:nth-child(odd) { border-right:1px solid var(--line-soft); }
    .spec-card dt { color:var(--muted); font-size:10px; font-weight:900; text-transform:uppercase; letter-spacing:.05em; }
    .spec-card dd { margin:5px 0 0; font-size:12px; color:var(--ink-soft); }
    .spec-card code { white-space:normal; overflow-wrap:anywhere; color:var(--accent-ink); }
    .spec-card .accept { background:var(--ok-soft); }.spec-card .riskline { background:var(--warn-soft); }
    .architecture-flow { display:grid; grid-template-columns:1fr auto 1fr auto 1fr auto 1fr; align-items:center; gap:8px; }
    .flow-node { min-height:112px; border:1px solid var(--line); border-radius:11px; padding:13px; display:flex; flex-direction:column; justify-content:center; background:var(--surface-soft); }
    .flow-node.new { border-color:color-mix(in srgb, var(--accent) 45%, var(--line)); background:var(--accent-soft); }
    .flow-node small { color:var(--muted); }.flow-node b { margin:3px 0; }.flow-node span { color:var(--ink-soft); font-size:11px; }.flow-arrow { color:var(--accent); font-weight:900; }
    .architecture-underlay { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:10px; margin-top:12px; }
    .architecture-underlay article { border:1px solid var(--line-soft); border-radius:10px; padding:12px; }.architecture-underlay b { font-size:13px; }.architecture-underlay p { margin-top:5px; color:var(--ink-soft); font-size:11px; }
    .roadmap-table { min-width:760px; }.roadmap-table .phase { font-weight:800; color:var(--accent-ink); white-space:nowrap; }
    .metric-strip { display:grid; grid-template-columns:repeat(5,minmax(0,1fr)); gap:8px; margin-top:12px; }
    .metric-strip>div { border:1px solid var(--line-soft); border-radius:10px; padding:10px; background:var(--surface-soft); }.metric-strip span,.metric-strip b { display:block; }.metric-strip span { color:var(--muted); font-size:10px; font-weight:800; }.metric-strip b { margin-top:4px; font-size:11px; }
    .do-not-copy { border-color:color-mix(in srgb,var(--warn) 30%,var(--line)); }.no-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px; }.no-grid article { border:1px solid var(--line-soft); border-radius:10px; padding:12px; background:var(--warn-soft); }.no-grid p { color:var(--ink-soft); font-size:12px; margin-top:5px; }
    @media (max-width:760px) { .function-toc { position:static; }.verdict-grid,.matrix-summary,.architecture-underlay,.metric-strip,.no-grid,.legend-grid { grid-template-columns:1fr; }.spec-card dl { grid-template-columns:1fr; }.spec-card dl>div:nth-child(odd){border-right:0}.architecture-flow { grid-template-columns:1fr; }.flow-arrow { transform:rotate(90deg); text-align:center; }.functional-matrix{min-width:900px} }
    @media print { .function-toc{display:none}.functional-matrix,.roadmap-table{min-width:0;font-size:8px}.functional-matrix th,.functional-matrix td,.roadmap-table th,.roadmap-table td{padding:5px}.spec-card{break-inside:avoid}.matrix-wrap{overflow:visible}.report-section{break-inside:auto} }
`;

html = html.replace('</style>', `${customCss}\n  </style>`);
html = html.replace('<p class="report-label">项目洞察报告</p>', '<p class="report-label">功能能力研究 · Functional Capability Review</p>');
html = html.replace('这部分只回答一个问题：现在最值得做的下一步是什么。', '先明确功能方向：借运营闭环，不复制通用外壳。');
html = html.replace(
  '<section class="report-section">\n          <div class="section-head">\n            <h2>项目上下文</h2>',
  `${functionSections}\n\n        <section class="report-section">\n          <div class="section-head">\n            <h2>研究范围与任务</h2>`
);
html = html.replaceAll('痛点优先级', '功能缺口优先级');
html = html.replaceAll('12 个不同人群体验评价', '12 个角色的功能验收视角');
html = html.replaceAll('把项目放到不同人群和岗位里试一遍，分别看价值、阻力和下一步方法。', '从真实使用、运营、成本、安全和交付角色检查这些功能是否成立。');
html = html.replaceAll('最终目标用户判断', '第一批功能验证用户');
html = html.replaceAll('12 类人群体验之后，必须收敛到第一优先服务的人群，避免谁都想服务。', '功能上线先服务任务频繁、要对结果和成本负责的人，避免泛化成通用 Agent 平台。');
html = html.replaceAll('项目洞察报告', '功能能力报告');

fs.writeFileSync(outputPath, html);
console.log(outputPath.pathname);
