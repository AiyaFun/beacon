import { parseJson } from '@/lib/json';
import { prisma } from '@/lib/db';
import { LEGAL_VERSION } from '@/lib/legal';
import { dataInventory, inventoryToCounts, resolveTenantScope, type TenantScope } from './inventory';

// 全量数据导出（PIPL 第 45 条可携带权 / PRD §6 F9-8「数据导出」）。
//
// 一个文件、机器可读、不需要我们这边配合就能读懂——这是「可携带」的最低门槛，
// 分成十几个 CSV 让用户自己拼关系就不算。故：单个 JSON，关联数据按归属嵌套。
//
// 【铁律：凭证类字段永不出现在导出包里】
// BYOK 的 apiKeyEnc、机器人的 secretsEnc、工作区采集令牌、会话 token、邀请 token——
// 一个都不导。它们是「访问权」而非「用户数据」，导出包一旦落到别人手上就是一串可直接用的钥匙；
// 而用户对这些字段的合理诉求（我配了哪家、还在不在）用元信息就能满足。
// 下面凡是含密字段的模型一律显式 select，绝不 findMany 裸取——新增字段时默认不外泄。

export const EXPORT_FORMAT_VERSION = '1';

type Grouped<T> = Map<string, T[]>;

function groupBy<T, K extends keyof T>(rows: T[], key: K): Grouped<T> {
  const m: Grouped<T> = new Map();
  for (const r of rows) {
    const k = String(r[key]);
    const bucket = m.get(k);
    if (bucket) bucket.push(r);
    else m.set(k, [r]);
  }
  return m;
}

function pick<T>(m: Grouped<T>, id: string): T[] {
  return m.get(id) ?? [];
}

function maskPhone(phone: string | null): string | null {
  if (!phone) return null;
  return phone.replace(/^(\d{3})\d{4}(\d{4})$/, '$1****$2');
}

export type ExportBundle = Record<string, unknown>;

/**
 * 组装导出包。范围 = 当前租户的全部业务数据（团队工作区里，成员共享同一份数据）。
 * 全局共享的竞对档案/热榜不属于本租户，只导「你订阅了谁」这一层关系。
 */
export async function buildAccountExport(opts: { tenantId: string; memberId: string }): Promise<ExportBundle> {
  const scope = await resolveTenantScope(opts.tenantId);
  const { tenantId, workspaceIds, accountIds } = scope;
  const byAccount = { accountId: { in: accountIds } };
  const byWorkspace = { workspaceId: { in: workspaceIds } };

  const [tenant, me, members, workspaces, accounts] = await Promise.all([
    prisma.tenant.findUnique({ where: { id: tenantId } }),
    prisma.member.findUnique({ where: { id: opts.memberId } }),
    prisma.member.findMany({ where: { tenantId }, orderBy: { createdAt: 'asc' } }),
    // ingestToken 是采集凭证，不导（见文件头铁律），只导「有没有启用」。
    // IngestToken 表同理：**整张表都不进导出**——它每一行都是一枚可直接使用的凭证，
    // 导出文件本身是可离线传播的副本，凭证进去就等于凭证泄漏。「已授权几台设备」
    // 在注销清单（lib/account/inventory.ts）里如实列出，那里只有计数没有令牌串。
    prisma.workspace.findMany({
      where: { tenantId },
      select: {
        id: true, name: true, automationConfig: true, createdAt: true, ingestToken: true,
        _count: { select: { ingestTokens: { where: { revokedAt: null } } } },
      },
    }),
    prisma.creatorAccount.findMany({ where: byWorkspace, orderBy: { createdAt: 'asc' } }),
  ]);

  const drafts = await prisma.draft.findMany({
    where: byAccount,
    include: { versions: { orderBy: { seq: 'asc' } }, checks: { orderBy: { checkedAt: 'asc' } } },
    orderBy: { createdAt: 'asc' },
  });

  const [
    personaVersions,
    materials,
    ownPosts,
    dailyStats,
    audience,
    topics,
    publishRecords,
    reviews,
    advisorSessions,
    advisorPersonas,
    memories,
    inspirations,
    watchlist,
    tasks,
    notifications,
    providers,
    bots,
    skillInstalls,
    customSkills,
    customWorkflows,
    workflowInstalls,
    schedules,
    taskPresets,
    procedureSkills,
    agentToolDefs,
    knowledgeBindings,
    workItems,
    agentLedgers,
    scrapeRecipes,
    scrapeRecords,
    aiCitations,
    coverStyles,
    orders,
    complianceFeedback,
  ] = await Promise.all([
    prisma.personaVersion.findMany({ where: byAccount, orderBy: { createdAt: 'asc' } }),
    prisma.material.findMany({ where: byAccount, orderBy: { createdAt: 'asc' } }),
    prisma.ownPost.findMany({ where: byAccount, orderBy: { publishedAt: 'asc' } }),
    prisma.accountDailyStat.findMany({ where: byAccount, orderBy: { date: 'asc' } }),
    prisma.audienceProfile.findMany({ where: byAccount }),
    prisma.topicIdea.findMany({ where: byAccount, orderBy: { createdAt: 'asc' } }),
    prisma.publishRecord.findMany({
      where: byAccount,
      include: { snapshots: { orderBy: { takenAt: 'asc' } } },
      orderBy: { publishedAt: 'asc' },
    }),
    prisma.reviewReport.findMany({ where: byAccount, orderBy: { createdAt: 'asc' } }),
    prisma.advisorSession.findMany({
      where: byAccount,
      include: { opinions: { orderBy: { createdAt: 'asc' } } },
      orderBy: { createdAt: 'asc' },
    }),
    prisma.advisorPersona.findMany({ where: byAccount }),
    // embedding 是几百维浮点数组，对人零可读性、能把导出包撑大一个量级——不导，元信息里写明
    prisma.memoryEntry.findMany({
      where: byWorkspace,
      select: {
        id: true, workspaceId: true, accountId: true, type: true, content: true,
        confidence: true, hitCount: true, active: true,
        validFrom: true, validTo: true, createdAt: true, updatedAt: true,
      },
      orderBy: { createdAt: 'asc' },
    }),
    prisma.inspirationItem.findMany({ where: byWorkspace, orderBy: { createdAt: 'asc' } }),
    // ⚠️ MediaAsset（参考图 / 生成的封面）**故意不导**，别顺手加上：导出包是可离线传播的副本，
    //    把人像照塞进去等于凭空多一份不受控的肖像拷贝；而且几十 MB 的 base64 会让 JSON 大到打不开。
    //    用户要图片可以在封面工位逐张下载。inventory 里如实列出它的条数。
    // ⚠️ ReaderComment（读者原声 / 评论正文）**故意不导**，别顺手加上。
    // 可携带权给的是「把**你的**个人信息带走」，而评论正文是**第三方个人**写下的内容——
    // 把它打进导出包，等于用一条用户权利把别人的话搬到我们控制不到的地方去。
    // 隐私政策里对这条有明文承诺（「不会被导出」），tests/legal/privacy-promises.test.ts 守着。
    // 用户想知道存了多少条，数据清单（lib/account/inventory.ts）里有。
    prisma.watchlistItem.findMany({ where: byWorkspace, include: { competitor: true } }),
    prisma.taskItem.findMany({ where: byWorkspace, orderBy: { createdAt: 'asc' } }),
    prisma.notification.findMany({ where: byWorkspace, orderBy: { createdAt: 'asc' } }),
    // apiKeyEnc 不导
    prisma.modelProvider.findMany({
      where: { tenantId },
      select: { id: true, label: true, vendor: true, baseUrl: true, model: true, region: true, routing: true, isDefault: true, status: true, createdAt: true },
    }),
    // secretsEnc / inboundKey 不导（inboundKey 是入站路由键，等同半个凭证）
    prisma.botIntegration.findMany({
      where: byWorkspace,
      select: { id: true, workspaceId: true, provider: true, label: true, enabled: true, pushEvents: true, pushSchedule: true, allowCommands: true, lastInboundAt: true, lastOutboundAt: true, lastError: true, createdAt: true },
    }),
    prisma.skillInstall.findMany({ where: { tenantId }, include: { skill: { select: { slug: true, name: true, platform: true, category: true, isBuiltin: true } } } }),
    prisma.contentSkill.findMany({ where: { tenantId } }),
    // 用户自建的智能体：steps 是他配出来的流水线、persona 是他写的职责，
    // 这两样都是「带得走才叫可携带」的核心
    prisma.workflowTemplate.findMany({ where: { tenantId }, orderBy: { createdAt: 'asc' } }),
    prisma.workflowInstall.findMany({
      where: { tenantId },
      include: { template: { select: { slug: true, name: true, emoji: true, category: true, isBuiltin: true } } },
    }),
    prisma.scheduledAgent.findMany({
      where: byWorkspace,
      orderBy: { createdAt: 'asc' },
      include: { template: { select: { slug: true, name: true } } },
    }),
    // 一键任务：和定时、自建智能体一样是**用户自己配出来的资产**——
    // 不导的话他搬到别处要凭记忆把每张卡的目标与授权范围重配一遍
    prisma.taskPreset.findMany({ where: byWorkspace, orderBy: [{ sort: 'asc' }, { createdAt: 'asc' }] }),
    // 做法技能：名字、说明、步骤都是从他自己跑通的任务里长出来的，搬走了才接得上
    prisma.procedureSkill.findMany({ where: byWorkspace, orderBy: { createdAt: 'asc' } }),
    // AI 自写工具：代码、参数、白名单都是在他的工作区里长出来的资产，搬走了才接得上
    prisma.agentToolDef.findMany({ where: byWorkspace, orderBy: { createdAt: 'asc' } }),
    // 员工知识范围（2026-09-11）：哪个模板读哪些资料——是他配的资产，搬走了才接得上
    prisma.agentKnowledgeBinding.findMany({ where: byWorkspace, orderBy: { createdAt: 'asc' } }),
    // 内容工单（2026-09-11）：流程状态与关联、驳回原因、返工次数；正文在草稿里另导
    prisma.contentWorkItem.findMany({ where: byWorkspace, orderBy: { createdAt: 'asc' }, include: { events: { orderBy: { createdAt: 'asc' } }, runs: { select: { runId: true } } } }),
    // 智能体台账：bot 自己记的盯单与进度（已见清单不导——那是去重用的中间态，且按 90 天滚动）
    prisma.agentLedger.findMany({ where: { ...byWorkspace, kind: 'kv' }, orderBy: [{ botSlug: 'asc' }, { key: 'asc' }] }),
    // 任意站点采集配方：站点、要抓什么、学到的规则——搬走了才能在别处接着用
    prisma.scrapeRecipe.findMany({ where: byWorkspace, orderBy: { createdAt: 'asc' } }),
    // 配方**抓到的数**。配方是「怎么抓」，这些才是「抓到了什么」——
    // 只导配方不导数据，等于让他把工具搬走、把成果留下。
    // 【为什么带上限】这张表按天增长（每配方每 6 小时一行），全量导会让导出文件失控；
    // 而它本来就只留 90 天，取最近这批足够回答「我采到过什么」。
    prisma.scrapeRecord.findMany({
      where: byWorkspace, orderBy: { capturedAt: 'desc' }, take: 5_000,
    }),
    // AI 引用回执：「我的哪篇内容被 AI 引用过」是他自己的经营事实，搬走了才接得上
    prisma.aiCitation.findMany({ where: byWorkspace, orderBy: { capturedAt: 'desc' }, take: 5_000 }),
    // 封面风格库：名字与画面描述都是用户自己写的（存量漏项，2026-08-22 上线前排查补上）
    prisma.coverStylePreset.findMany({ where: byWorkspace, orderBy: { createdAt: 'asc' } }),
    prisma.paymentOrder.findMany({ where: { tenantId }, orderBy: { createdAt: 'asc' } }),
    prisma.complianceFeedback.findMany({ where: { tenantId }, orderBy: { createdAt: 'asc' } }),
  ]);

  const draftsByAccount = groupBy(drafts, 'accountId');
  const personaByAccount = groupBy(personaVersions, 'accountId');
  const materialByAccount = groupBy(materials, 'accountId');
  const ownPostByAccount = groupBy(ownPosts, 'accountId');
  const dailyByAccount = groupBy(dailyStats, 'accountId');
  const audienceByAccount = groupBy(audience, 'accountId');
  const topicByAccount = groupBy(topics, 'accountId');
  const publishByAccount = groupBy(publishRecords, 'accountId');
  const reviewByAccount = groupBy(reviews, 'accountId');
  const advisorByAccount = groupBy(advisorSessions, 'accountId');
  const personaCardByAccount = groupBy(advisorPersonas, 'accountId');

  const inventory = await dataInventory(scope);

  return {
    // ── 元信息：这份文件是什么、怎么读、少了什么 ──
    meta: {
      product: '烽火台 · 跨平台内容作战室',
      formatVersion: EXPORT_FORMAT_VERSION,
      exportedAt: new Date().toISOString(),
      exportedBy: opts.memberId,
      tenantId,
      legalVersion: LEGAL_VERSION,
      scope: '当前工作区（租户）的全部业务数据。团队成员共享同一份数据，故导出范围与角色无关。',
      excluded: [
        'API Key / 机器人密钥 / 采集令牌 / 登录会话 token —— 属访问凭证而非用户数据，导出即等于把钥匙交出去',
        '记忆条目的向量（embedding）—— 数百维浮点数组，对人不可读且会把文件撑大一个量级；记忆正文已完整导出',
        '全局共享的竞对档案与热榜原文 —— 不属于本工作区的数据，只导出你的订阅关系',
      ],
      inventory,
    },

    // ── 账号与团队 ──
    account: me
      ? {
          id: me.id,
          name: me.name,
          phone: maskPhone(me.phone),
          email: me.email,
          wechatBound: !!me.wechatOpenId,
          role: me.role,
          status: me.status,
          consentAt: me.consentAt,
          consentVersion: me.consentVersion,
          createdAt: me.createdAt,
        }
      : null,
    tenant: tenant
      ? { id: tenant.id, name: tenant.name, plan: tenant.plan, planExpiresAt: tenant.planExpiresAt, createdAt: tenant.createdAt }
      : null,
    members: members.map((m) => ({
      id: m.id,
      name: m.name,
      phone: maskPhone(m.phone),
      wechatBound: !!m.wechatOpenId,
      role: m.role,
      status: m.status,
      createdAt: m.createdAt,
    })),
    workspaces: workspaces.map((w) => ({
      id: w.id,
      name: w.name,
      automationConfig: w.automationConfig,
      ingestTokenEnabled: !!w.ingestToken || w._count.ingestTokens > 0,
      authorizedDevices: w._count.ingestTokens,
      createdAt: w.createdAt,
    })),

    // ── 创作者账号：人设、素材、选题、草稿、发布、复盘、智囊团都挂在它下面 ──
    creatorAccounts: accounts.map((a) => ({
      id: a.id,
      name: a.name,
      platform: a.platform,
      handle: a.handle,
      status: a.status,
      personaCard: a.personaCard,
      styleFingerprint: a.styleFingerprint,
      createdAt: a.createdAt,
      personaVersions: pick(personaByAccount, a.id),
      materials: pick(materialByAccount, a.id),
      ownPosts: pick(ownPostByAccount, a.id),
      dailyStats: pick(dailyByAccount, a.id),
      audienceProfiles: pick(audienceByAccount, a.id),
      topics: pick(topicByAccount, a.id),
      drafts: pick(draftsByAccount, a.id),
      publishRecords: pick(publishByAccount, a.id),
      reviewReports: pick(reviewByAccount, a.id),
      advisorSessions: pick(advisorByAccount, a.id),
      advisorPersonas: pick(personaCardByAccount, a.id),
    })),

    // ── 工作区级 ──
    memories,
    inspirations,
    watchlist: watchlist.map((w) => ({
      id: w.id,
      label: w.label,
      addedAt: w.addedAt,
      competitor: w.competitor
        ? { platform: w.competitor.platform, handle: w.competitor.handle, name: w.competitor.name, followers: w.competitor.followers }
        : null,
    })),
    tasks,
    notifications,

    // ── 配置与账务 ──
    modelProviders: providers,
    botIntegrations: bots,
    skills: {
      installs: skillInstalls.map((i) => ({ id: i.id, enabled: i.enabled, createdAt: i.createdAt, skill: i.skill })),
      custom: customSkills,
    },
    // 智能体 = 工作流模板。与 skills 同构：装了哪些 + 自己建了哪些。
    // custom 里的 steps/persona 是用户自己配的流水线与职责说明——「带得走」主要指这两样。
    agents: {
      // WorkflowInstall 的时间字段叫 installedAt（不是 createdAt，与 SkillInstall 不同名）
      installs: workflowInstalls.map((i) => ({ id: i.id, enabled: i.enabled, installedAt: i.installedAt, template: i.template })),
      custom: customWorkflows,
      // 定时计划：跟着智能体一起导，否则用户搬到别处要凭记忆重配一遍几点几分跑哪个
      schedules: schedules.map((r) => ({
        id: r.id,
        template: r.template,
        atHour: r.atHour,
        atMinute: r.atMinute,
        weekdays: r.weekdays,
        enabled: r.enabled,
        lastRunAt: r.lastRunAt,
        lastStatus: r.lastStatus,
        createdAt: r.createdAt,
      })),
      // 封面风格库：他写的名字与画面描述
      coverStyles: coverStyles.map((c) => ({
        id: c.id, name: c.name, description: c.description, createdAt: c.createdAt,
      })),
      // 一键任务：目标、让谁干、授权到什么程度——三样都是他配的，缺一样搬过去就得重想一遍
      // 采集配方：连学到的规则一起导出——只导站点和字段名的话，换个地方还得重学一遍
      scrapeRecipes: scrapeRecipes.map((r) => ({
        id: r.id,
        name: r.name,
        origin: r.origin,
        pathPattern: r.pathPattern,
        fields: parseJson<{ key: string; label: string }[]>(r.fields, []),
        rules: parseJson<{ key: string; selectors: string[]; anchors: string[] }[]>(r.rules, []),
        version: r.version,
        status: r.status,
        createdAt: r.createdAt,
      })),
      // 做法技能：步骤与工具白名单一并导出——只导名字的话，换个地方重建不出同一个技能
      procedureSkills: procedureSkills.map((p) => ({
        id: p.id,
        name: p.name,
        description: p.description,
        goal: p.goal,
        steps: parseJson<{ tool: string; why: string }[]>(p.steps, []),
        toolAllowlist: parseJson<string[]>(p.toolAllowlist, []),
        usedCount: p.usedCount,
        createdAt: p.createdAt,
      })),
      // AI 自写工具：连代码一起导（status 也导：草稿/启用是他审过的结果）
      aiTools: agentToolDefs.map((t) => ({
        id: t.id,
        name: t.name,
        label: t.label,
        description: t.description,
        params: parseJson<Record<string, unknown>>(t.params, {}),
        uses: parseJson<string[]>(t.uses, []),
        code: t.code,
        status: t.status,
        usedCount: t.usedCount,
        createdAt: t.createdAt,
      })),
      knowledgeBindings: knowledgeBindings.map((b) => ({
        id: b.id, templateId: b.templateId, sourceType: b.sourceType, sourceId: b.sourceId, purpose: b.purpose, priority: b.priority, enabled: b.enabled, createdAt: b.createdAt,
      })),
      workItems: workItems.map((w) => ({
        id: w.id, accountId: w.accountId, title: w.title, stage: w.stage, status: w.status, ownerMemberId: w.ownerMemberId, agentTemplateId: w.agentTemplateId,
        dueAt: w.dueAt, inputs: w.inputs, acceptance: w.acceptance, topicId: w.topicId, draftId: w.draftId, publishPlanId: w.publishPlanId, publishRecordId: w.publishRecordId,
        runIds: w.runs.map((r) => r.runId), rejectReason: w.rejectReason, reworkCount: w.reworkCount, acceptedAt: w.acceptedAt, createdAt: w.createdAt,
        events: w.events.map((e) => ({ kind: e.kind, fromStage: e.fromStage, toStage: e.toStage, note: e.note, refKind: e.refKind, refId: e.refId, memberId: e.memberId, at: e.createdAt })),
      })),
      aiCitations: aiCitations.map((c) => ({
        id: c.id,
        engine: c.engine,
        question: c.question,
        answerUrl: c.answerUrl,
        sourceUrl: c.sourceUrl,
        sourceTitle: c.sourceTitle,
        platform: c.platform,
        isMine: c.isMine,
        capturedAt: c.capturedAt,
      })),
      // 采集到的数：值、取到几个、什么时候、走的哪条通道
      scrapeRecords: scrapeRecords.map((r) => ({
        id: r.id,
        recipeId: r.recipeId,
        url: r.url,
        values: parseJson<Record<string, string>>(r.values, {}),
        rows: parseJson<Record<string, string>[]>(r.rows, []),
        rowCount: r.rowCount,
        got: r.got,
        want: r.want,
        channel: r.channel,
        capturedAt: r.capturedAt,
      })),
      taskPresets: taskPresets.map((p) => ({
        id: p.id,
        title: p.title,
        goal: p.goal,
        agentTemplateId: p.agentTemplateId,
        authMode: p.authMode,
        preauthorizedTools: parseJson<string[]>(p.preauthorizedTools, []),
        enabled: p.enabled,
        createdAt: p.createdAt,
      })),
      agentLedgers: agentLedgers.map((l) => ({ botSlug: l.botSlug, key: l.key, value: l.value, updatedAt: l.updatedAt })),
    },
    complianceFeedback,
    payments: orders.map((o) => ({
      outTradeNo: o.outTradeNo,
      transactionId: o.transactionId,
      plan: o.plan,
      periodMonths: o.periodMonths,
      amountFen: o.amountFen,
      amountYuan: (o.amountFen / 100).toFixed(2),
      currency: o.currency,
      status: o.status,
      paidAt: o.paidAt,
      grantedDays: o.grantedDays,
      newPlanExpiresAt: o.newPlanExpiresAt,
      createdAt: o.createdAt,
    })),

    counts: inventoryToCounts(inventory),
  };
}

export type { TenantScope };
