import { getSession } from '@/lib/session';
import { loadGeneProfile } from '@/lib/insight/genes';
import { Card, Stat, Meter, Empty, LinkButton } from '@/components/ui';

// 「爆款基因」面板 —— 原 /genes 页的主体，现为「看效果」页的一个标签。
// 自包含：自己取 session + gene profile，只在 view=genes 被激活时才渲染（见 /data/page.tsx 的早返回）。

function pct(x: number): string {
  return `${Math.round(x * 100)}%`;
}

export async function GenesPanel({ lang }: { lang?: string } = {}) {
  const isEn = lang === 'en';
  const s = await getSession();
  const profile = await loadGeneProfile(s.accountId);

  if (profile.sample === 0) {
    return (
      <Empty
        icon="🧬"
        text={isEn ? 'No published content with view/play data yet. Publish a few posts and track performance to see your content gene profile here.' : '还没有带播放数据的已发布内容。发布几条并回流数据后，这里会长出你自己的基因画像。'}
        action={<LinkButton href="/data">{isEn ? 'Record post performance' : '去数据看板登记发布'}</LinkButton>}
      />
    );
  }

  return (
    <>
      <div className="grid grid-3" style={{ marginBottom: 16 }}>
        <Stat
          label={isEn ? 'Total Posts Analyzed' : '参与统计'}
          value={profile.sample}
          foot={isEn ? `Posts with view data in the last ${profile.windowDays} days` : `近 ${profile.windowDays} 天有播放数据的作品`}
        />
        <Stat
          label={isEn ? 'Strongest Gene' : '最强的一项'}
          value={profile.headline ? pct(profile.headline.winRate) : '—'}
          foot={
            profile.headline
              ? `${profile.headline.dimension}: ${profile.headline.label} (${profile.headline.sample} ${isEn ? 'posts' : '条'})`
              : (isEn ? 'Insufficient data for conclusion' : '样本还不够，暂不下结论')
          }
        />
        <Stat
          label={isEn ? 'Win Rate Baseline' : '胜率口径'}
          value={isEn ? 'Beat Own Average' : '跑赢自己'}
          foot={isEn ? 'Post views ≥ your average on the same platform counts as a win' : '该条播放 ≥ 你在同平台的均播，才算赢'}
        />
      </div>

      <Card style={{ marginBottom: 16, background: 'var(--surface-2)', boxShadow: 'none' }}>
        <p className="small" style={{ margin: 0, lineHeight: 1.8 }}>
          {isEn
            ? 'Every metric on this page can be verified: Win rate = number of posts in this category beating your platform average ÷ total posts in this category. '
            : '这一页的每个数都可以自己验算：胜率 = 该类里跑赢你同平台均播的条数 ÷ 该类总条数。'}
          <b>
            {isEn
              ? 'Categories with under 3 posts only show counts, not win rates'
              : ' 不足 3 条的类别只报条数、不报胜率'}
          </b>
          {isEn
            ? ' — winning 1 out of 2 is inconclusive, not a 50% win rate. Baselines compare with your own recent works in the same window, not peaks from 6 months ago.'
            : '——2 条里赢 1 条不是 50% 胜率，是没有结论。基线取的是同一窗口内你自己的作品，不拿半年前的高水位去比最近的内容。'}
        </p>
      </Card>

      <div className="stack" style={{ gap: 16 }}>
        {profile.dimensions.map((d) => (
          <Card key={d.key} title={d.name} sub={d.hint}>
            {d.buckets.length === 0 ? (
              <p className="small muted" style={{ margin: 0 }}>
                {isEn ? 'No categorized data yet.' : '还没有可归类的数据。'}
                {d.key === 'source' || d.key === 'angle'
                  ? (isEn
                      ? ' This dimension requires topic attribution at publish time — only content adopted from the topic engine has sources and angles.'
                      : '这一维需要发布时带上选题归因——从选题引擎采纳并发布的内容才有来源和切入角。')
                  : ''}
              </p>
            ) : (
              <div className="stack" style={{ gap: 10 }}>
                {!d.conclusive && (
                  <p className="small muted" style={{ margin: 0 }}>
                    {isEn
                      ? 'Fewer than 3 posts in each category; showing counts only until enough data accumulates.'
                      : '每一类都还不到 3 条，先只列条数，攒够再下结论。'}
                  </p>
                )}
                {d.buckets.map((b) => (
                  <div key={b.key}>
                    <div className="row-between" style={{ gap: 12, alignItems: 'baseline' }}>
                      <span className="small" style={{ flex: 1, minWidth: 0 }}>{b.label}</span>
                      <span className="small muted">
                        {b.sample} {isEn ? 'posts' : '条'}
                        {b.winRate === null ? '' : (isEn ? ` · ${b.wins} wins` : ` · 赢 ${b.wins}`)}
                        {isEn ? ' · Avg ' : ' · 平均 '}
                        {b.avgRatio.toFixed(2)} {isEn ? 'x avg' : '倍均播'}
                      </span>
                      <b style={{ minWidth: 52, textAlign: 'right' }}>
                        {b.winRate === null ? <span className="small muted">{isEn ? 'Sample too small' : '样本不足'}</span> : pct(b.winRate)}
                      </b>
                    </div>
                    {b.winRate !== null && (
                      <Meter value={b.winRate * 100} color={b.winRate >= 0.5 ? 'var(--green)' : 'var(--amber)'} />
                    )}
                  </div>
                ))}
              </div>
            )}
          </Card>
        ))}
      </div>
    </>
  );
}
